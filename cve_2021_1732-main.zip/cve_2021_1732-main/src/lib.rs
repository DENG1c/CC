#![feature(asm)]
pub mod patchcallbacktable;
pub use patchcallbacktable::*;